DS <- function(jarray, name){
  # 將向量轉換java array
  jarray <- .jarray(as.double(jarray))
  # 宣告一個DescriptiveStatistics物件
  ds <- .jnew("DescriptiveStatistics", jarray, name)
  return(ds)
}

LR <- function(v1, v2, name){
  # 將向量轉換java array
  v1 <- .jarray(as.double(v1))
  v2 <- .jarray(as.double(v2))
  # 宣告一個LinearRegression物件
  lr <- .jnew("LinearRegression", v1, v2, name)
  return(lr)
}

LR_DS <- function(DS,vector){
  # 將向量轉換java array
  array <- .jarray(as.double(vector))
  # 宣告一個LinearRegression物件
  lr <- .jnew("LinearRegression",DS$getData(), array,DS$getName())
  return(lr)
}

LR_predict <- function(lr, x){
  # 將向量轉換java array
  x <- as.double(x)
  # 宣告一個LinearRegression物件
  y <- lr$predict(x)
  return(y)
}

AN <- function(list_of_vector, name){
  # 將向量轉換java array
  list_of_vector <- lapply(list_of_vector, as.double)
  list_of_array <- lapply(list_of_vector, .jarray)
  D2 <- .jarray(list_of_array,"[D")
  # 宣告一個Analysis物件
  an <- .jnew("Anova",D2, name)
  return(an)
}

